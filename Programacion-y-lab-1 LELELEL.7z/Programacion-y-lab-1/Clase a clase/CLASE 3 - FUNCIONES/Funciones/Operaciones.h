

/** \brief Calcula el factorial de un numero
 *
 * \param int El numero sobre el que se hara el calculo
 * \return int El factorial del numero
 *
 */
 int calcularFactorial();
